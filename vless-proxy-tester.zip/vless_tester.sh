#!/bin/bash

# Получаем путь к папке приложения
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
RESOURCES_DIR="$APP_DIR"
VLESS_URL_FILE="$APP_DIR/vless-url.txt"
RESULTS_FILE="$APP_DIR/test-results.txt"
WORKING_PROXIES="$APP_DIR/working-proxies.txt"

# Бинарник xray (должен быть в той же папке)
XRAY_BINARY="$APP_DIR/xray"
CONFIG_FILE="/tmp/test-config.json"
PID_FILE="/tmp/xray-test.pid"
LOG_FILE="/tmp/xray-test.log"

# Создаем папки
mkdir -p "$RESOURCES_DIR"

# Функции
log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

is_running() {
    [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null
}

stop_xray() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if kill -0 $pid 2>/dev/null; then
            log "Остановка Xray (PID: $pid)"
            kill $pid
            sleep 2
            if kill -0 $pid 2>/dev/null; then
                kill -9 $pid
                log "Принудительная остановка Xray"
            fi
        fi
        rm -f "$PID_FILE"
    fi
}

start_xray() {
    log "Запуск Xray с конфигом: $CONFIG_FILE"
    nohup "$XRAY_BINARY" run -config "$CONFIG_FILE" >> "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    sleep 3
    
    if is_running; then
        log "✅ Xray успешно запущен (PID: $(cat "$PID_FILE"))"
        return 0
    else
        log "❌ Ошибка запуска Xray"
        log "Проверьте лог: $LOG_FILE"
        return 1
    fi
}

# Проверка подключения с текущим конфигом
test_connection() {
    log "Проверка подключения..."
    if curl --socks5 127.0.0.1:1080 -s --max-time 10 http://ifconfig.me >/dev/null 2>&1; then
        local proxy_ip=$(curl --socks5 127.0.0.1:1080 -s --max-time 10 http://ifconfig.me 2>/dev/null)
        if [ -n "$proxy_ip" ]; then
            log "✅ Подключение работает! IP: $proxy_ip"
            return 0
        fi
    fi
    log "❌ Подключение не работает"
    return 1
}

# Декодирование VLESS-ссылки
decode_vless_url() {
    local vless_url="$1"
    
    log "Декодирование VLESS-ссылки..."
    
    # Проверка что это VLESS ссылка
    if [[ ! "$vless_url" =~ ^vless:// ]]; then
        log "❌ Ошибка: Это не VLESS ссылка"
        return 1
    fi
    
    # Убираем префикс vless://
    local without_prefix="${vless_url#vless://}"
    
    # Извлекаем fragment (часть после #)
    local fragment=""
    if [[ "$without_prefix" == *"#"* ]]; then
        fragment="${without_prefix#*#}"
        without_prefix="${without_prefix%#*}"
    fi
    
    # Извлекаем query string (часть после ?)
    local query_string=""
    if [[ "$without_prefix" == *"?"* ]]; then
        query_string="${without_prefix#*\?}"
        without_prefix="${without_prefix%\?*}"
    fi
    
    # Разбираем основную часть: uuid@server:port
    local uuid="${without_prefix%@*}"
    local server_part="${without_prefix#*@}"
    local server="${server_part%:*}"
    local port="${server_part#*:}"
    
    # URL decode fragment
    fragment=$(echo "$fragment" | sed 's/%/\\x/g')
    fragment=$(echo -e "$fragment")
    
    log "Парсинг:"
    log "   UUID: '$uuid'"
    log "   Сервер: '$server'"
    log "   Порт: '$port'"
    log "   Название: '$fragment'"
    
    # Извлекаем параметры из query string
    local security="none"
    local network="tcp"
    local fp="chrome"
    local sni=""
    local pbk=""
    local sid=""
    local path=""
    local host=""
    local headerType=""
    local flow=""
    local spx=""
    
    if [[ -n "$query_string" ]]; then
        IFS='&' read -ra params <<< "$query_string"
        for param in "${params[@]}"; do
            local key="${param%=*}"
            local value="${param#*=}"
            # URL decode значения
            value=$(echo "$value" | sed 's/%/\\x/g')
            value=$(echo -e "$value")
            
            case "$key" in
                "security") security="$value" ;;
                "type") network="$value" ;;
                "fp") fp="$value" ;;
                "sni") sni="$value" ;;
                "pbk") pbk="$value" ;;
                "sid") sid="$value" ;;
                "path") path="$value" ;;
                "host") host="$value" ;;
                "headerType") headerType="$value" ;;
                "flow") flow="$value" ;;
                "spx") spx="$value" ;;
            esac
        done
    fi
    
    log "   Security: '$security'"
    log "   Network: '$network'"
    log "   Fingerprint: '$fp'"
    log "   SNI: '$sni'"
    log "   Public Key: '$pbk'"
    log "   Short ID: '$sid'"
    log "   Path: '$path'"
    log "   Host: '$host'"
    log "   Header Type: '$headerType'"
    log "   Flow: '$flow'"
    log "   SpiderX: '$spx'"
    
    # Валидация
    if [[ -z "$uuid" || -z "$server" || -z "$port" ]]; then
        log "❌ Неверный формат VLESS-ссылки после парсинга"
        return 1
    fi
    
    # Создаем правильный конфиг
    cat > "$CONFIG_FILE" << EOF
{
  "inbounds": [
    {
      "port": 1080,
      "listen": "127.0.0.1",
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "vless",
      "settings": {
        "vnext": [
          {
            "address": "$server",
            "port": $port,
            "users": [
              {
                "id": "$uuid",
                "encryption": "none"
EOF

    # Добавляем flow если есть
    if [[ -n "$flow" ]]; then
        cat >> "$CONFIG_FILE" << EOF
                ,
                "flow": "$flow"
EOF
    fi

    cat >> "$CONFIG_FILE" << EOF
              }
            ]
          }
        ]
      },
      "streamSettings": {
        "network": "$network",
        "security": "$security",
EOF

    # Добавляем настройки для REALITY
    if [[ "$security" == "reality" ]]; then
        cat >> "$CONFIG_FILE" << EOF
        "realitySettings": {
          "fingerprint": "$fp",
          "serverName": "$sni",
          "publicKey": "$pbk",
          "shortId": "$sid",
          "spiderX": "$spx",
          "show": false
        }
EOF
    # Добавляем настройки для разных типов network
    elif [[ "$network" == "ws" ]]; then
        cat >> "$CONFIG_FILE" << EOF
        "wsSettings": {
          "path": "$path"
EOF
        if [[ -n "$host" ]]; then
            cat >> "$CONFIG_FILE" << EOF
          ,
          "headers": {
            "Host": "$host"
          }
EOF
        fi
        cat >> "$CONFIG_FILE" << EOF
        }
EOF
    elif [[ "$network" == "http" || "$network" == "h2" ]]; then
        cat >> "$CONFIG_FILE" << EOF
        "httpSettings": {
          "path": "$path"
EOF
        if [[ -n "$host" ]]; then
            cat >> "$CONFIG_FILE" << EOF
          ,
          "host": ["$host"]
EOF
        fi
        cat >> "$CONFIG_FILE" << EOF
        }
EOF
    elif [[ "$network" == "grpc" ]]; then
        cat >> "$CONFIG_FILE" << EOF
        "grpcSettings": {
          "serviceName": "${path:-/}",
          "multiMode": false
        }
EOF
    elif [[ "$network" == "tcp" && -n "$headerType" ]]; then
        cat >> "$CONFIG_FILE" << EOF
        "tcpSettings": {
          "header": {
            "type": "$headerType"
          }
        }
EOF
    else
        # Простой TCP без дополнительных настроек
        cat >> "$CONFIG_FILE" << EOF
        "tcpSettings": {}
EOF
    fi

    # Завершаем конфиг
    cat >> "$CONFIG_FILE" << EOF
      },
      "tag": "proxy"
    }
  ]
}
EOF

    log "✅ Конфиг создан из VLESS-ссылки"
    log "   Сервер: $server:$port"
    log "   UUID: ${uuid:0:8}..."
    log "   Тип: $security/$network"
    log "   Flow: $flow"
    return 0
}

# Тестирование одной ссылки
test_single_url() {
    local url="$1"
    local name="$2"
    
    echo "========================================"
    log "Тестирование: $name"
    
    # Декодируем ссылку и создаем конфиг
    if ! decode_vless_url "$url"; then
        echo "❌ Ошибка декодирования ссылки"
        return 1
    fi
    
    # Останавливаем предыдущий запуск если есть
    stop_xray
    
    # Запускаем Xray
    if start_xray; then
        # Ждем инициализации прокси
        sleep 2
        
        # Тестируем подключение
        if test_connection; then
            echo "✅ РАБОТАЕТ - $name" >> "$RESULTS_FILE"
            echo "$url" >> "$WORKING_PROXIES"
            log "✅ Прокси рабочий - добавлен в список"
        else
            echo "❌ НЕ РАБОТАЕТ - $name" >> "$RESULTS_FILE"
            log "❌ Прокси не работает"
        fi
    else
        echo "❌ ОШИБКА ЗАПУСКА - $name" >> "$RESULTS_FILE"
        log "❌ Не удалось запустить Xray"
    fi
    
    # Останавливаем Xray перед переходом к следующей ссылке
    stop_xray
    sleep 1
}

# Основная функция тестирования
main_test() {
    echo "=== VLESS Proxy Tester ==="
    echo ""
    
    # Проверяем наличие файла с ссылками
    if [ ! -f "$VLESS_URL_FILE" ]; then
        echo "❌ Файл с ссылками не найден: $VLESS_URL_FILE"
        echo "Создайте файл vless-url.txt со списком VLESS ссылок"
        exit 1
    fi
    
    # Проверяем xray
    if [ ! -f "$XRAY_BINARY" ]; then
        echo "❌ Xray бинарник не найден: $XRAY_BINARY"
        echo "Поместите xray в ту же папку что и скрипт"
        exit 1
    fi
    
    # Делаем xray исполняемым
    chmod +x "$XRAY_BINARY"
    
    # Очищаем файлы результатов
    > "$RESULTS_FILE"
    > "$WORKING_PROXIES"
    
    # Читаем ссылки из файла
    local count=1
    local total=0
    
    # Считаем общее количество непустых строк
    while IFS= read -r url; do
        # Пропускаем пустые строки и комментарии
        if [[ -n "$url" && ! "$url" =~ ^[[:space:]]*# && ! "$url" =~ ^[[:space:]]*$ ]]; then
            ((total++))
        fi
    done < "$VLESS_URL_FILE"
    
    echo "Найдено ссылок для тестирования: $total"
    echo "========================================"
    
    # Снова читаем файл для тестирования
    while IFS= read -r url; do
        # Пропускаем пустые строки
        if [[ -z "$url" || "$url" =~ ^[[:space:]]*$ ]]; then
            continue
        fi
        
        # Пропускаем комментарии
        if [[ "$url" =~ ^[[:space:]]*# ]]; then
            continue
        fi
        
        # Извлекаем имя из фрагмента
        local name="Unknown"
        if [[ "$url" == *"#"* ]]; then
            name="${url##*#}"
            # Убираем лишние пробелы
            name=$(echo "$name" | xargs)
        fi
        
        echo "[$count/$total]"
        test_single_url "$url" "$name"
        echo ""
        ((count++))
    done < "$VLESS_URL_FILE"
    
    # Вывод результатов
    echo "========================================"
    echo "РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ:"
    echo "========================================"
    
    if [ -f "$RESULTS_FILE" ]; then
        cat "$RESULTS_FILE"
    fi
    
    echo ""
    echo "========================================"
    
    if [ -f "$WORKING_PROXIES" ] && [ -s "$WORKING_PROXIES" ]; then
        local working_count=$(wc -l < "$WORKING_PROXIES" | tr -d ' ')
        echo "✅ Найдено рабочих прокси: $working_count"
        echo "📄 Список сохранен в: $WORKING_PROXIES"
        echo ""
        echo "РАБОЧИЕ ПРОКСИ:"
        cat "$WORKING_PROXIES"
    else
        echo "❌ Рабочих прокси не найдено"
    fi
    
    # Очистка временных файлов
    rm -f "$CONFIG_FILE" "$PID_FILE"
    
    echo ""
    echo "Тестирование завершено!"
}

# Запуск тестирования
main_test